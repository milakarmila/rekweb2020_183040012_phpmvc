<?php 

class User_model{
	private $nama = "Mila";

	public function getUser(){
		return $this->nama;
	}
}