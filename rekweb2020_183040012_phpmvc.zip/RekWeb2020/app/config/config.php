<?php 


define('BASEURL', 'http://localhost/rekweb2020/public');

//DB
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_HOST', '');
define('DB_NAME', 'phpmvc');
